# VirtLab — Flutter (migrado desde Kodular/App Inventor)

## Qué es esto

Todo el código Dart (`lib/`) está completo: las 14 pantallas del flujo
completo (Splash → Bienvenida → Login/Registro → Personalización →
Menú → Química/Física/Biología → Preguntas → Labi → Logros → Perfil →
Acerca de), con el contenido real de los 14 experimentos migrado
textualmente del `.aia` original, más autenticación, Firestore,
Storage, FCM, personalización con vista previa en vivo, daltonismo y
sistema de logros funcional (incluye el logro "Sin prisa" que en el
original estaba a medio implementar).

## Lo que NO pude hacer en este entorno (y por qué)

Este chat no tiene acceso a internet ni al SDK de Flutter/Android, así
que **no pude**:

1. Correr `flutter create` para generar las carpetas nativas
   `android/` e `ios/` — este proyecto solo trae `lib/`, `pubspec.yaml`
   y `assets/`, no una app Android compilable todavía.
2. Correr `flutter pub get` (no hay red para bajar los paquetes).
3. Compilar, probar en un dispositivo/emulador, ni generar el APK
   final — la Fase 4 (Pruebas) y Fase 5 (Generar APK) de tu
   especificación quedan pendientes de correr de tu lado.
4. Configurar Authentication/Firestore/Storage en la consola real de
   Firebase — el `google-services.json` que subiste solo tiene la API
   key del proyecto `labi-2622a`, sin Auth ni reglas configuradas.

## Antes de compilar — configura Appwrite Storage (foto de perfil)

La foto de perfil se sube a Appwrite Storage (gratis, sin tarjeta,
sin Firebase Storage).

1. Crea una cuenta gratis en [cloud.appwrite.io](https://cloud.appwrite.io).
2. Crea un proyecto nuevo. En Project Settings copia el **Project
   ID** y el **endpoint** de tu región (ej.
   `https://fra.cloud.appwrite.io/v1`).
3. Ve a **Storage → Create bucket**. Copia el **Bucket ID**.
4. Dentro del bucket, en **Settings → Permissions**, agrega Role =
   "Any" con "Read" activado (así cualquiera puede ver las fotos ya
   subidas).
5. Ve a **Overview → Integrations → API Keys → Create API Key**, con
   scope `files.write` (y `files.read`). Copia esa key.
6. Abre `lib/config/appwrite_config.dart` en el zip y reemplaza
   `TU_ENDPOINT_AQUI`, `TU_PROJECT_ID_AQUI` y `TU_BUCKET_ID_AQUI` con
   tus valores (estos tres NO son secretos).
7. En GitHub: **Settings → Secrets and variables → Actions → New
   repository secret** → nombre `APPWRITE_API_KEY` → pega la key del
   paso 5 (esta sí es secreta, nunca va en el código).

## Opción A — Compilar el APK en la nube con GitHub Actions (sin instalar nada)

Ya incluí el workflow en `.github/workflows/build-apk.yml`. Pasos:

1. Crea un repositorio nuevo en GitHub (puede ser privado) y sube
   **todo** el contenido de este zip tal cual (arrastra la carpeta
   completa en la web de GitHub, o usa `git push` si tienes Git).
2. En el repo: **Settings → Secrets and variables → Actions → New
   repository secret**.
   - Nombre: `GOOGLE_SERVICES_JSON_BASE64`
   - Valor: pega el contenido del archivo `google-services-base64.txt`
     que te compartí junto con este zip (ya es tu `google-services.json`
     real, codificado en base64 — el workflow lo decodifica solo).
3. Ve a **[Firebase Console](https://console.firebase.google.com)** → tu proyecto ("labi") →
   **Build → AI Logic** → **Get started** → elige **"Gemini Developer API"**
   (tiene capa gratuita) → sigue el asistente hasta que quede activado.
   Ya no necesitas crear ningún secreto de API key para Labi — Firebase
   AI Logic no requiere que la app cargue ninguna key.
4. La app usa Firebase **App Check** (proveedor "debug", pensado para
   estos APK de prueba). La primera vez que abras Labi en el celular,
   si App Check está en modo "Enforced" en la consola, puede que el
   mensaje de error te muestre un token de depuración — cópialo y
   regístralo en **Firebase Console → Project settings → App Check
   → Apps → (tu app Android) → Manage debug tokens**. Si prefieres
   evitarte este paso mientras pruebas, pon App Check en modo
   **"Unenforced"/"Monitor only"** temporalmente desde esa misma
   pantalla, y actívalo estricto ("Enforced") solo cuando publiques
   la versión final en Play Store.
5. Ve a la pestaña **Actions** del repo → selecciona "Build VirtLab
   APK" → **Run workflow**.
6. Cuando termine (unos 5-8 minutos), entra a esa ejecución y baja el
   artefacto **virtlab-apk** — ahí está tu `app-release.apk`, listo
   para instalar en cualquier Android.

Nota: el APK saldrá firmado con la clave de debug de Flutter, lo cual
es perfecto para probar en cualquier dispositivo. Para publicarlo en
Google Play vas a necesitar firmarlo con tu propio keystore de
producción (te ayudo con eso cuando llegues a ese paso).

## Opción B — Compilarlo tú localmente

```bash
# 1. Descomprime este zip y entra a la carpeta
cd virtlab_flutter

# 2. Genera las carpetas nativas SIN pisar lib/ ni pubspec.yaml
flutter create --org com.virtlab --project-name virtlab .

# 3. Copia tu google-services.json real a android/app/google-services.json

# 4. En android/build.gradle añade el classpath de Google services,
#    y en android/app/build.gradle aplica el plugin
#    com.google.gms.google-services (guía oficial de FlutterFire).

# 5. Instala dependencias
flutter pub get

# 6. Compila el APK
flutter build apk --release
```

## Cosas que necesitan una decisión tuya antes de producción

- **API key de Gemini expuesta**: el `.aia` original traía la key de
  Gemini escrita en texto plano. No la reutilicé en este código —
  debes regenerarla en Google AI Studio y, en vez de llamarla
  directo desde el cliente, desplegar una Cloud Function que la
  guarde como secreto de servidor. `lib/services/labi_service.dart`
  ya está escrito para llamar a esa función; falta desplegarla.
- **Recordatorios diarios de FCM**: el envío en sí (🧪🔬🏆🎯) necesita
  un cron en el backend (Cloud Scheduler + Cloud Functions, por
  ejemplo) que llame a la API de FCM — un dispositivo no puede
  "programarse a sí mismo" notificaciones mientras la app está
  completamente cerrada.
- **Logro "Sin prisa" (logro_lento)**: en el proyecto original ese tag
  se leía/escribía pero nunca tuvo tarjeta ni condición visible en
  Logros. Implementé una condición razonable (tardar más de 3 minutos
  respondiendo) inferida del temporizador que sí existía en
  Q_Preguntas — confírmala o ajústala si el equipo tenía otra idea.
- Los íconos `logrocolor_5/6/7/8/10.png` (y sus versiones gris) no
  corresponden a ningún logro definido en el proyecto original — están
  en `assets/` por si quieren usarlos para logros nuevos, pero no
  inventé nombres ni condiciones para ellos.

──────────────────────────────

## Migración a Flutter Web (GitHub Pages) — lo que se hizo y lo que falta

El código Dart ya es 100% compatible con Web: se quitó el único uso de
`dart:io` (subida de foto de perfil, que ahora usa `XFile.readAsBytes()`
en vez de `File`, funcionando igual en Android/iOS/Web), se agregó
`lib/firebase_options.dart` para que Firebase también inicialice en el
navegador, y se agregó soporte de VAPID key para notificaciones push
en Web (`messaging_service.dart`). Ninguna pantalla, color, navegación
ni funcionalidad cambió — Android sigue compilando exactamente igual
que antes.

También se agregó una carpeta `web/` (index.html, manifest.json,
favicon e íconos generados desde `assets/images/virtlab.png`) y el
workflow `.github/workflows/deploy-web.yml`, que compila y publica en
GitHub Pages automáticamente en cada push a `main` (con
`base-href` calculado solo del nombre del repo, así funciona sin
importar cómo se llame).

**Este chat tampoco tiene acceso al SDK de Flutter ni a internet**, así
que —igual que con la Fase 4/5 del build de Android— no pude correr
`flutter pub get` ni `flutter build web` para confirmar que compila
sin errores. Debe verificarse en el primer run del workflow.

### Bloqueante real: falta registrar un "Web app" en Firebase

Android usa `google-services.json` (secreto `GOOGLE_SERVICES_JSON_BASE64`)
para conectarse al proyecto `labi-2622a`. Web no usa ese archivo — necesita
las credenciales del "Web app" que se registra aparte en Firebase Console.
Son datos públicos (no secretos), pero son específicos del proyecto y
nadie los inventó acá. Pasos:

1. Firebase Console → proyecto `labi-2622a` → ⚙️ Configuración del
   proyecto → pestaña "Tus apps" → agregar app Web (ícono `</>`).
2. Copiar los valores de `firebaseConfig` (`apiKey`, `authDomain`,
   `projectId`, `storageBucket`, `messagingSenderId`, `appId`).
3. Cargarlos como Secrets nuevos del repo (Settings → Secrets and
   variables → Actions), sin tocar los que ya existen:
   - `FIREBASE_WEB_API_KEY`
   - `FIREBASE_WEB_AUTH_DOMAIN`
   - `FIREBASE_WEB_PROJECT_ID`
   - `FIREBASE_WEB_STORAGE_BUCKET`
   - `FIREBASE_WEB_MESSAGING_SENDER_ID`
   - `FIREBASE_WEB_APP_ID`
4. (Opcional, solo para que Labi avise por notificación push en Web)
   Firebase Console → Cloud Messaging → "Certificados push web" →
   generar par de claves → guardar como Secret `FIREBASE_VAPID_KEY`.
   Si no se configura, la app funciona igual, simplemente no habrá
   push en Web.
5. En Firebase Console → Authentication → Settings → "Authorized
   domains", agregar `TU-USUARIO.github.io` (si no aparece ya).
6. Activar GitHub Pages: Settings → Pages → Source = "GitHub Actions".

Sin el paso 1-3, la app compila y se ve idéntica, pero Login/Registro/
Firestore van a fallar en Web (Android sigue funcionando normal,
porque no depende de estos Secrets nuevos).

### Nota de seguridad (no bloqueante, solo para que lo sepan)

En Android, `GROQ_API_KEY` y `APPWRITE_API_KEY` quedan embebidas en el
APK compilado — ya son extraíbles con esfuerzo. En Web quedan en el
JS/Wasm que se descarga en el navegador, visibles con solo abrir las
herramientas de desarrollador (pestaña Red). No cambié esto porque la
instrucción fue conservar los Secrets tal cual y no rediseñar la
arquitectura, pero si en algún momento quieren cerrar esto del todo,
la solución estándar es mover esas dos llamadas (Groq y Appwrite) a
una Cloud Function que guarde las keys del lado del servidor.
