import 'package:flutter/material.dart';

enum ColorBlindMode { none, deuteranopia, protanopia, tritanopia, acromatopsia }

extension ColorBlindModeX on ColorBlindMode {
  String get label {
    switch (this) {
      case ColorBlindMode.none:
        return 'Ninguno';
      case ColorBlindMode.deuteranopia:
        return 'Deuteranopia';
      case ColorBlindMode.protanopia:
        return 'Protanopia';
      case ColorBlindMode.tritanopia:
        return 'Tritanopia';
      case ColorBlindMode.acromatopsia:
        return 'Acromatopsia';
    }
  }

  static ColorBlindMode fromStorage(String value) {
    return ColorBlindMode.values.firstWhere(
      (m) => m.name == value,
      orElse: () => ColorBlindMode.none,
    );
  }

  /// Matrices de CORRECCIÓN (daltonización), no de simulación.
  ///
  /// La idea: para alguien con deuteranopia/protanopia (dificultad
  /// rojo-verde), la información de color que se "pierde" entre rojo
  /// y verde se redistribuye hacia el canal azul, que sí perciben
  /// bien — así dos colores que antes se veían casi iguales quedan
  /// más separados. Para tritanopia (dificultad azul-amarillo) se
  /// redistribuye hacia rojo/verde en su lugar.
  ///
  /// Estas matrices salen de: corrección = I + E·(I − S), donde S es
  /// una aproximación estándar (Brettel/Viénot) de qué tanto de cada
  /// color deja de percibirse, y E decide hacia qué canales se
  /// redistribuye lo perdido. Es una aproximación práctica (el
  /// algoritmo "daltonize" clásico), no una simulación de cómo ve la
  /// persona.
  List<double>? get colorMatrix {
    switch (this) {
      case ColorBlindMode.none:
        return null;
      case ColorBlindMode.deuteranopia:
        return [
          1.0, 0.0, 0.0, 0, 0,
          -0.438, 1.438, 0.0, 0, 0,
          0.262, -0.562, 1.3, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case ColorBlindMode.protanopia:
        return [
          1.0, 0.0, 0.0, 0, 0,
          -0.255, 1.255, 0.0, 0, 0,
          0.303, -0.545, 1.242, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case ColorBlindMode.tritanopia:
        return [
          1.05, -0.382, 0.332, 0, 0,
          0.0, 1.234, -0.234, 0, 0,
          0.0, 0.0, 1.0, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case ColorBlindMode.acromatopsia:
        // Para acromatopsia (ceguera total al color) no existe
        // "redistribución" posible — no hay canal de color sano hacia
        // donde mover información. Lo único que realmente ayuda es
        // maximizar el contraste, así que se muestra en escala de
        // grises con buen contraste en vez de intentar "corregir"
        // colores que esa persona no percibe en absoluto.
        return [
          0.299, 0.587, 0.114, 0, 0,
          0.299, 0.587, 0.114, 0, 0,
          0.299, 0.587, 0.114, 0, 0,
          0, 0, 0, 1, 0,
        ];
    }
  }
}

/// Envuelve toda la app para aplicar la corrección de color elegida
/// en "Personaliza tu experiencia". Se aplica una sola vez en
/// main.dart, sobre TODA la navegación — no pantalla por pantalla —
/// para que ninguna pantalla se quede sin la corrección.
class ColorBlindFilter extends StatelessWidget {
  final ColorBlindMode mode;
  final Widget child;
  const ColorBlindFilter({super.key, required this.mode, required this.child});

  @override
  Widget build(BuildContext context) {
    final matrix = mode.colorMatrix;
    if (matrix == null) return child;
    return ColorFiltered(
      colorFilter: ColorFilter.matrix(matrix),
      child: child,
    );
  }
}
