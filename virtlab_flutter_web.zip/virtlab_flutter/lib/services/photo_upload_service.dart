import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import '../config/appwrite_config.dart';

/// Sube fotos de perfil a Appwrite Storage y devuelve la URL pública
/// de la imagen.
///
/// ⚠️ La API key de Appwrite NUNCA vive en este archivo. Se recibe
/// únicamente al compilar:
///
///   flutter build apk --release --dart-define=APPWRITE_API_KEY=tu_key
///
/// En GitHub Actions esa key se guarda como Secret del repositorio
/// (Settings → Secrets and variables → Actions → APPWRITE_API_KEY).
class PhotoUploadService {
  static const String _apiKey = String.fromEnvironment('APPWRITE_API_KEY');

  /// Recibe un [XFile] (de image_picker) en vez de dart:io File, porque
  /// dart:io no existe en Flutter Web — XFile.readAsBytes() sí funciona
  /// igual en Android, iOS y Web.
  Future<String> uploadProfilePhoto(XFile file) async {
    if (!AppwriteConfig.isConfigured) {
      throw Exception('Falta configurar Appwrite en lib/config/appwrite_config.dart');
    }
    if (_apiKey.isEmpty) {
      throw Exception('Falta la API key de Appwrite (APPWRITE_API_KEY) al compilar.');
    }

    final fileId = 'unique()';
    final uri = Uri.parse(
      '${AppwriteConfig.endpoint}/storage/buckets/${AppwriteConfig.bucketId}/files',
    );

    final bytes = await file.readAsBytes();

    final request = http.MultipartRequest('POST', uri)
      ..headers['X-Appwrite-Project'] = AppwriteConfig.projectId
      ..headers['X-Appwrite-Key'] = _apiKey
      ..fields['fileId'] = fileId
      ..fields['permissions[]'] = 'read("any")'
      ..files.add(http.MultipartFile.fromBytes('file', bytes, filename: file.name));

    final streamedResponse = await request.send().timeout(const Duration(seconds: 30));
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode != 200 && response.statusCode != 201) {
      throw Exception('No se pudo subir la foto (HTTP ${response.statusCode}): ${response.body}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final realFileId = data['\$id'] as String?;
    if (realFileId == null) throw Exception('Appwrite no devolvió un ID de archivo válido.');

    return '${AppwriteConfig.endpoint}/storage/buckets/${AppwriteConfig.bucketId}/files/'
        '$realFileId/view?project=${AppwriteConfig.projectId}';
  }
}
