import '../models/experiment.dart';

/// Contenido migrado desde Q_Intro.bky / Q_Preguntas.bky (proyecto
/// original de Kodular). Materiales/pasos como checklist y preguntas
/// de opción múltiple; ningún experimento ni contenido fue eliminado.
const List<Experiment> quimicaExperiments = [
  Experiment(
    id: 'vinagre',
    title: 'Vinagre + Bicarbonato',
    materials: ['Vinagre', 'Bicarbonato', '1 vaso'],
    steps: ['Agrega vinagre al vaso', 'Añade bicarbonato', 'Observa la reacción'],
    questions: [
      Question(
        text: '¿Qué observaste cuando mezclaste los materiales?',
        options: ['El líquido se congeló', 'Se formó espuma y burbujas', 'No pasó nada', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿Qué crees que causó la reacción?',
        options: ['La luz del sol', 'El calor del ambiente', 'Una reacción química entre un ácido y una base', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué gas piensas que se liberó?',
        options: ['Oxígeno', 'Hidrógeno', 'Dióxido de carbono (CO2)', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
    ],
  ),
  Experiment(
    id: 'burbujas',
    title: 'Burbujas en Líquido',
    materials: ['Agua', 'Vinagre', 'Bicarbonato', '1 vaso'],
    steps: [
      'Coloca agua en el vaso',
      'Agrega un poco de vinagre',
      'Añade una cucharada de bicarbonato',
      'Observa la reacción',
    ],
    questions: [
      Question(
        text: '¿Qué observaste al agregar el bicarbonato a la mezcla?',
        options: ['Se formaron burbujas rápidamente', 'El líquido se evaporó', 'El líquido cambió de color', 'No estoy seguro/a'],
        correctIndex: 0,
      ),
      Question(
        text: '¿Por qué crees que se formaron burbujas?',
        options: ['Por el movimiento al mezclar', 'Por el aire que ya tenía el vaso', 'Por la liberación de gas durante la reacción', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué cambio ocurrió en el líquido después de la reacción?',
        options: ['Se volvió sólido', 'Quedó con menos burbujas y más estable', 'Cambió de sabor', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
    ],
  ),
  Experiment(
    id: 'lava',
    title: 'Lámpara de lava',
    materials: ['Agua', 'Aceite', 'Colorante', 'Alka-Seltzer', '1 vaso transparente'],
    steps: [
      'Llena con agua el vaso hasta la mitad',
      'Agrega aceite hasta casi llenar el recipiente',
      'Añade un poco de colorante',
      'Coloca la pastilla en el líquido',
      'Agrégale una luz por debajo y observa',
    ],
    questions: [
      Question(
        text: '¿Qué sucede al mezclar el aceite y el agua?',
        options: ['Se combinan por completo', 'El aceite se hunde', 'No se mezclan, quedan separados en capas', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Por qué el colorante no se mezcla completamente con el aceite?',
        options: ['Porque el colorante es soluble en agua, no en aceite', 'Porque el colorante es sólido', 'Porque el aceite está muy frío', 'No estoy seguro/a'],
        correctIndex: 0,
      ),
      Question(
        text: '¿Qué provoca el movimiento de las burbujas dentro del líquido?',
        options: ['El movimiento del vaso', 'El calor de la luz de abajo', 'El gas liberado por la pastilla efervescente', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
    ],
  ),
  Experiment(
    id: 'limon',
    title: 'Tinta invisible',
    materials: ['Jugo de limón', 'Papel', 'Hisopo', 'Una fuente de calor'],
    steps: [
      'Moja un hisopo en jugo de limón',
      'Escribe o dibuja en una hoja de papel',
      'Déjala secar',
      'Aplícale calor con cuidado y observa lo que pasa',
    ],
    questions: [
      Question(
        text: '¿Qué ocurre cuando aplicas calor al papel?',
        options: ['El papel se moja', 'No pasa nada', 'El dibujo se oscurece y se hace visible', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué cambio ocurrió en el papel?',
        options: ['El papel se volvió transparente', 'El jugo de limón se oxidó y oscureció con el calor', 'El papel cambió de textura', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿Por qué crees que pasó eso?',
        options: ['El limón reacciona con la luz', 'El papel absorbe calor y cambia de color por sí solo', 'El calor acelera la oxidación de los compuestos del limón', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
    ],
  ),
  Experiment(
    id: 'presion',
    title: 'Colapso por presión',
    materials: ['Lata vacía', 'Agua', 'Fuente de calor', 'Recipiente con agua fría', 'Pinzas'],
    steps: [
      'Agrega un poco de agua dentro de la lata',
      'Coloca la lata sobre una fuente de calor hasta que empiece a hervir',
      'Con cuidado, voltea la lata rápidamente dentro de un recipiente con agua fría',
      'Observa lo que ocurre',
    ],
    questions: [
      Question(
        text: '¿Qué ocurrió con la lata al colocarla en agua fría?',
        options: ['No cambió', 'Explotó', 'Se aplastó/colapsó rápidamente', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué crees que causó ese cambio en la lata?',
        options: ['El agua fría la hizo más pesada', 'El vapor dentro se enfrió y bajó la presión interna', 'El calor de la estufa la debilitó', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿Por qué el cambio ocurre tan rápido?',
        options: ['Porque el metal es muy delgado', 'Porque el agua fría es más densa', 'Porque la diferencia de presión adentro y afuera es muy grande', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
    ],
  ),
  Experiment(
    id: 'serpiente',
    title: 'Serpiente negra',
    materials: ['Azúcar', 'Bicarbonato', 'Arena', 'Alcohol', 'Encendedor'],
    steps: [
      'Coloca arena formando una pequeña montaña',
      'Mezcla azúcar con bicarbonato',
      'Coloca la mezcla sobre la arena',
      'Añade un poco de alcohol',
      'Enciende la mezcla con mucho cuidado y observa lo que pasa',
    ],
    questions: [
      Question(
        text: '¿Qué ocurre al encender la mezcla?',
        options: ['Se apaga de inmediato', 'Se forma una especie de serpiente de carbón que crece', 'Solo se quema la arena', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿Por qué la sustancia hace eso?',
        options: ['El bicarbonato se derrite', 'La arena reacciona con el fuego', 'El azúcar se descompone en carbono al quemarse y se expande', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Por qué el cambio ocurre tan rápido?',
        options: ['Por la alta temperatura del alcohol encendido', 'Por el viento', 'Por la humedad de la arena', 'No estoy seguro/a'],
        correctIndex: 0,
      ),
    ],
  ),
];
