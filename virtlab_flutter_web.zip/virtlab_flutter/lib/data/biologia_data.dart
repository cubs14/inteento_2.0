import '../models/experiment.dart';

/// Contenido migrado desde B_Intro.bky / B_Preguntas.bky. Materiales
/// y pasos como checklist, preguntas de opción múltiple.
const List<Experiment> biologiaExperiments = [
  Experiment(
    id: 'pulmon',
    title: 'Pulmón casero',
    materials: ['1 botella plástica', '2 globos', '1 pajilla', 'Cinta adhesiva', 'Tijeras'],
    steps: [
      'Corta la botella por la mitad',
      'Coloca un globo dentro de la botella conectado a la pajilla',
      'Cubre la parte inferior con otro globo estirado',
      'Tira del globo inferior',
      'Observa cómo el globo interior se infla simulando un pulmón',
    ],
    questions: [
      Question(
        text: '¿Qué crees que representa el globo dentro de la botella?',
        options: ['El corazón', 'Un pulmón', 'El estómago', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿Qué sucede al tirar del globo inferior?',
        options: ['El globo interior se infla, simulando la respiración', 'El globo interior se desinfla del todo', 'La botella se rompe', 'No estoy seguro/a'],
        correctIndex: 0,
      ),
      Question(
        text: '¿Qué sistema del cuerpo se representa?',
        options: ['El sistema digestivo', 'El sistema circulatorio', 'El sistema respiratorio', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
    ],
  ),
  Experiment(
    id: 'frijol',
    title: 'Germinación de frijol',
    materials: ['1 frijol', 'Algodón', 'Agua', 'Vaso transparente'],
    steps: [
      'Coloca algodón dentro del vaso',
      'Humedece el algodón con agua',
      'Pon el frijol sobre el algodón',
      'Deja el vaso cerca de la luz',
      'Observa su crecimiento durante varios días',
    ],
    questions: [
      Question(
        text: '¿Qué necesita el frijol para crecer?',
        options: ['Solo oscuridad', 'Agua, luz y tiempo', 'Sal y aceite', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿Dónde debe colocarse el vaso?',
        options: ['En un lugar completamente oscuro', 'Dentro del refrigerador', 'Cerca de la luz', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué observamos después de unos días?',
        options: ['El frijol desaparece', 'El frijol germina y le crece una raíz/tallo', 'El algodón cambia de color', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
    ],
  ),
  Experiment(
    id: 'transpiracion',
    title: 'Transpiración de plantas',
    materials: ['Hojas de una planta', 'Bolsa transparente', 'Cinta'],
    steps: [
      'Coloca una bolsa alrededor de una hoja o rama',
      'Ciérrala con cinta',
      'Déjala bajo la luz durante unas horas',
      'Observa las gotas de agua dentro de la bolsa',
      'Comprueba cómo la planta libera agua',
    ],
    questions: [
      Question(
        text: '¿Qué aparece dentro de la bolsa?',
        options: ['Aceite', 'Gotas de agua', 'Nada, queda seca', 'No estoy seguro/a'],
        correctIndex: 1,
      ),
      Question(
        text: '¿Qué demuestra este experimento?',
        options: ['Que las plantas producen aceite', 'Que las plantas no necesitan agua', 'Que las plantas liberan agua (transpiración)', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué libera la planta?',
        options: ['Oxígeno líquido', 'Azúcar', 'Vapor de agua', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
    ],
  ),
  Experiment(
    id: 'adn',
    title: 'ADN de tomate',
    materials: ['Tomate', 'Jabón líquido', 'Sal', 'Agua', 'Alcohol', 'Vaso'],
    steps: [
      'Tritura el tomate en un vaso',
      'Mezcla agua, jabón y sal',
      'Agrega la mezcla al tomate',
      'Añade lentamente alcohol',
      'Observa las fibras blancas del ADN',
    ],
    questions: [
      Question(
        text: '¿Qué parte blanca aparece en el experimento?',
        options: ['Restos de jabón', 'Semillas del tomate', 'Fibras de ADN', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué fruta o verdura usamos?',
        options: ['Limón', 'Papa', 'Tomate', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
      Question(
        text: '¿Qué sustancia ayuda a separar el ADN?',
        options: ['El agua sola', 'La sal sola', 'El alcohol', 'No estoy seguro/a'],
        correctIndex: 2,
      ),
    ],
  ),
];
