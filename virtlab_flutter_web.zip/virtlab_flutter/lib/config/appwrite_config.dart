/// Configuración de Appwrite Storage para las fotos de perfil.
///
/// El endpoint, el ID de proyecto y el ID del bucket NO son secretos
/// (son identificadores públicos, igual que el "cloud name" de otros
/// servicios) — van directo aquí. La API key sí es secreta y NUNCA
/// va en este archivo: se recibe solo al compilar, vía
/// --dart-define=APPWRITE_API_KEY=... (ver photo_upload_service.dart).
///
/// Pasos para configurarlo (una sola vez, gratis, sin tarjeta):
/// 1. Crea una cuenta en https://cloud.appwrite.io
/// 2. Crea un proyecto nuevo. Copia su "Project ID" y pégalo abajo en
///    [projectId]. Copia también el endpoint de la región que te
///    asignó (se ve en Project Settings, algo como
///    "https://fra.cloud.appwrite.io/v1") y pégalo en [endpoint].
/// 3. Ve a **Storage** → **Create bucket**. Ponle un nombre (ej.
///    "fotos-perfil"). Copia su "Bucket ID" y pégalo en [bucketId].
/// 4. Dentro del bucket, en **Settings → Permissions**, agrega un
///    permiso con Role = "Any" y marca "Read" (así cualquiera puede
///    VER las fotos ya subidas — no afecta quién puede subir, eso lo
///    controla la API key).
/// 5. Ve a **Overview → Integrations → API Keys → Create API Key**.
///    Dale el scope "files.write" (y "files.read" para estar
///    seguros). Copia esa key — esa sí va como secreto de GitHub
///    (APPWRITE_API_KEY), nunca aquí.
class AppwriteConfig {
  static const String endpoint = 'https://nyc.cloud.appwrite.io/v1';
  static const String projectId = '6a655d1b0020c10955c3';
  static const String bucketId = '6a655d710014fa41247a';

  static bool get isConfigured =>
      endpoint != 'TU_ENDPOINT_AQUI' &&
      projectId != 'TU_PROJECT_ID_AQUI' &&
      bucketId != 'TU_BUCKET_ID_AQUI';
}
