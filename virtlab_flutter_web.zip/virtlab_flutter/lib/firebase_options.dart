import 'package:firebase_core/firebase_core.dart';

/// Configuración de Firebase para Flutter Web.
///
/// Android e iOS siguen inicializando Firebase exactamente igual que
/// antes (sin FirebaseOptions, usando google-services.json /
/// GoogleService-Info.plist nativos) — este archivo NO los toca.
///
/// Flutter Web sí necesita estas credenciales explícitas porque no
/// existe un "google-services.json" nativo para el navegador. Son
/// datos públicos (igual que un Project ID), no secretos — Firebase
/// los protege con las reglas de seguridad de Firestore/Storage/Auth,
/// no ocultándolos. Aun así, viajan como --dart-define en el workflow
/// para no hardcodear el proyecto Firebase de VirtLab directamente en
/// el código fuente.
///
/// Para obtenerlos: Firebase Console → Configuración del proyecto →
/// "Tus apps" → agrega una app Web (</>) si todavía no existe una →
/// copia los valores del objeto `firebaseConfig` que te muestra.
class DefaultFirebaseOptions {
  static const String _apiKey = String.fromEnvironment('FIREBASE_WEB_API_KEY');
  static const String _authDomain = String.fromEnvironment('FIREBASE_WEB_AUTH_DOMAIN');
  static const String _projectId = String.fromEnvironment('FIREBASE_WEB_PROJECT_ID');
  static const String _storageBucket = String.fromEnvironment('FIREBASE_WEB_STORAGE_BUCKET');
  static const String _messagingSenderId =
      String.fromEnvironment('FIREBASE_WEB_MESSAGING_SENDER_ID');
  static const String _appId = String.fromEnvironment('FIREBASE_WEB_APP_ID');

  static bool get isConfigured => _apiKey.isNotEmpty && _appId.isNotEmpty && _projectId.isNotEmpty;

  static FirebaseOptions get web => FirebaseOptions(
        apiKey: _apiKey,
        authDomain: _authDomain,
        projectId: _projectId,
        storageBucket: _storageBucket,
        messagingSenderId: _messagingSenderId,
        appId: _appId,
      );
}
