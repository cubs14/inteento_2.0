import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'screens/splash_screen.dart';
import 'state/app_state.dart';
import 'theme/colorblind.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Android/iOS: igual que siempre, sin options (usa
  // google-services.json / GoogleService-Info.plist nativos).
  // Web: no existe ese archivo nativo, así que necesita las
  // credenciales explícitas del "Web app" de Firebase (ver
  // lib/firebase_options.dart).
  if (kIsWeb) {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.web);
  } else {
    await Firebase.initializeApp();
  }
  // App Check queda desactivado por ahora: el proveedor "debug" exige
  // registrar manualmente un token (vía adb/logcat) para que las
  // peticiones no fallen con "App attestation failed" — mucha
  // fricción para APKs de prueba compilados en GitHub Actions. Como
  // "Firebase AI Logic" ya está en modo "No aplicado" en la consola,
  // Labi funciona igual sin este paso.
  //
  // Antes de publicar en Play Store: activar App Check con
  // AndroidProvider.playIntegrity (import 'package:firebase_app_check
  // /firebase_app_check.dart') y volver a poner "Aplicado" en la
  // consola, para que la protección sea real en producción.
  runApp(const VirtLabApp());
}

class VirtLabApp extends StatelessWidget {
  const VirtLabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(),
      child: Consumer<AppState>(
        builder: (context, state, _) {
          return MaterialApp(
            title: 'VirtLab',
            debugShowCheckedModeBanner: false,
            // El tema se reconstruye con los colores que el usuario
            // eligió en "Personaliza tu experiencia" (o los valores
            // por defecto de VirtLab antes de personalizar). Al vivir
            // aquí, en la raíz de la app, se aplica automáticamente a
            // TODAS las pantallas — ninguna pantalla necesita fijar
            // sus propios colores a mano.
            theme: ThemeData(
              useMaterial3: true,
              scaffoldBackgroundColor: state.backgroundColor,
              colorScheme: ColorScheme.fromSeed(
                seedColor: state.buttonColor,
                primary: state.buttonColor,
              ),
              appBarTheme: AppBarTheme(
                backgroundColor: state.buttonColor,
                foregroundColor: Colors.white,
              ),
              textTheme: Theme.of(context).textTheme.apply(
                    bodyColor: state.textColor,
                    displayColor: state.textColor,
                  ),
              elevatedButtonTheme: ElevatedButtonThemeData(
                style: ElevatedButton.styleFrom(
                  backgroundColor: state.buttonColor,
                  foregroundColor: Colors.white,
                  textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 24),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  elevation: 4,
                ),
              ),
            ),
            // La corrección de daltonismo también se aplica aquí,
            // envolviendo TODA la navegación de la app de una sola
            // vez — así ninguna pantalla queda sin corregir.
            builder: (context, child) => ColorBlindFilter(
              mode: state.colorBlindMode,
              // Responsive para Web/desktop/tablet: el diseño de
              // VirtLab se pensó para ancho de celular, así que en
              // pantallas anchas centramos ese mismo diseño en vez de
              // estirarlo (igual que WhatsApp Web o Twitter). En
              // celular (ancho <= 600) esto no cambia absolutamente
              // nada: el contenido ya ocupa todo el ancho disponible.
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final content = child ?? const SizedBox.shrink();
                  if (constraints.maxWidth <= 600) return content;
                  return Container(
                    color: state.backgroundColor,
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      width: 600,
                      child: content,
                    ),
                  );
                },
              ),
            ),
            home: const SplashScreen(),
          );
        },
      ),
    );
  }
}
