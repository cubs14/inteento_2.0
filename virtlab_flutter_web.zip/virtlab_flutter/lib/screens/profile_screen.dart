import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../models/user_profile.dart';
import '../services/photo_upload_service.dart';
import '../state/app_state.dart';
import 'terms_screen.dart';
import 'welcome_screen.dart';

/// Pantalla Perfil: foto de perfil (editable), nombre de usuario
/// (editable), correo (solo lectura), términos y condiciones, y
/// botón de cerrar sesión.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _photoUploader = PhotoUploadService();
  bool _uploadingPhoto = false;
  bool _editingUsername = false;
  bool _savingUsername = false;
  late final TextEditingController _usernameCtrl;
  String? _photoError;

  @override
  void initState() {
    super.initState();
    _usernameCtrl = TextEditingController();
  }

  @override
  void dispose() {
    _usernameCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickAndUploadPhoto(ImageSource source) async {
    final state = context.read<AppState>();
    final profile = state.profile;
    if (profile == null) return;

    final picker = ImagePicker();
    final picked = await picker.pickImage(source: source, maxWidth: 800, imageQuality: 85);
    if (picked == null) return;

    setState(() {
      _uploadingPhoto = true;
      _photoError = null;
    });
    try {
      final url = await _photoUploader.uploadProfilePhoto(picked);
      await state.firestoreService.updatePhotoUrl(profile.uid, url);
      state.profile = profile.copyWith(photoUrl: url);
      state.notifyListeners();
    } catch (e) {
      setState(() => _photoError = 'No se pudo subir la foto. Inténtalo de nuevo.');
    } finally {
      if (mounted) setState(() => _uploadingPhoto = false);
    }
  }

  void _showPhotoOptions() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Tomar fotografía'),
              onTap: () {
                Navigator.pop(context);
                _pickAndUploadPhoto(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Elegir desde la galería'),
              onTap: () {
                Navigator.pop(context);
                _pickAndUploadPhoto(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _saveUsername(UserProfile profile) async {
    final newUsername = _usernameCtrl.text.trim();
    if (newUsername.isEmpty || newUsername == profile.username) {
      setState(() => _editingUsername = false);
      return;
    }
    setState(() => _savingUsername = true);
    final state = context.read<AppState>();
    await state.firestoreService.updateUsername(profile.uid, newUsername);
    state.profile = UserProfile(
      uid: profile.uid,
      username: newUsername,
      email: profile.email,
      photoUrl: profile.photoUrl,
      level: profile.level,
      xp: profile.xp,
    );
    state.notifyListeners();
    if (mounted) {
      setState(() {
        _savingUsername = false;
        _editingUsername = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final profile = state.profile;
    final unlockedCount = state.achievements.where((a) => a.unlocked).length;

    return Scaffold(
      appBar: AppBar(title: const Text('Perfil'), foregroundColor: Colors.white),
      body: profile == null
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: ListView(
                padding: const EdgeInsets.all(24),
                children: [
                  Center(
                    child: GestureDetector(
                      onTap: _uploadingPhoto ? null : _showPhotoOptions,
                      child: Stack(
                        children: [
                          CircleAvatar(
                            radius: 56,
                            backgroundColor: Colors.white,
                            backgroundImage: profile.photoUrl.startsWith('http')
                                ? NetworkImage(profile.photoUrl)
                                : AssetImage(profile.photoUrl) as ImageProvider,
                          ),
                          if (_uploadingPhoto)
                            Positioned.fill(
                              child: CircleAvatar(
                                backgroundColor: Colors.black38,
                                child: const CircularProgressIndicator(color: Colors.white),
                              ),
                            ),
                          Positioned(
                            right: 0,
                            bottom: 0,
                            child: CircleAvatar(
                              radius: 16,
                              backgroundColor: Theme.of(context).colorScheme.primary,
                              child: const Icon(Icons.edit, size: 16, color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (_photoError != null) ...[
                    const SizedBox(height: 8),
                    Text(_photoError!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red)),
                  ],
                  const SizedBox(height: 24),

                  // Nombre de usuario (editable)
                  Text('Nombre de usuario', style: const TextStyle(fontSize: 13, color: Colors.black54)),
                  const SizedBox(height: 4),
                  if (_editingUsername)
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _usernameCtrl,
                            autofocus: true,
                            decoration: const InputDecoration(isDense: true),
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                          ),
                        ),
                        _savingUsername
                            ? const Padding(
                                padding: EdgeInsets.all(8),
                                child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                              )
                            : IconButton(
                                icon: const Icon(Icons.check),
                                onPressed: () => _saveUsername(profile),
                              ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => setState(() => _editingUsername = false),
                        ),
                      ],
                    )
                  else
                    Row(
                      children: [
                        Expanded(
                          child: Text(profile.username, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, size: 20),
                          onPressed: () {
                            _usernameCtrl.text = profile.username;
                            setState(() => _editingUsername = true);
                          },
                        ),
                      ],
                    ),
                  const SizedBox(height: 18),

                  _infoRow('Correo electrónico', profile.email),
                  _infoRow('Nivel', profile.level.toString()),
                  _infoRow('XP', profile.xp.toString()),
                  _infoRow('Logros obtenidos', '$unlockedCount / ${state.achievements.length}'),

                  const SizedBox(height: 20),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.description_outlined),
                    title: const Text('Términos y condiciones'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const TermsScreen()),
                    ),
                  ),

                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await state.logout();
                        if (!context.mounted) return;
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const WelcomeScreen()),
                          (route) => false,
                        );
                      },
                      icon: const Icon(Icons.logout, color: Colors.red),
                      label: const Text('Cerrar sesión', style: TextStyle(color: Colors.red)),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        side: const BorderSide(color: Colors.red),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, color: Colors.black54)),
          Text(value.isEmpty ? '—' : value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
