/// Una pregunta de opción múltiple dentro de un experimento.
/// `options` siempre incluye, al final, la opción "No estoy seguro/a".
class Question {
  final String text;
  final List<String> options;
  final int correctIndex;

  const Question({
    required this.text,
    required this.options,
    required this.correctIndex,
  });

  int get unsureIndex => options.length - 1;
}

/// Representa un experimento dentro de una ciencia (Química, Física o
/// Biología). Materiales y pasos se guardan como listas (mismo
/// contenido migrado del proyecto original de Kodular, solo separado
/// en elementos para mostrarse como checklist en vez de un párrafo).
class Experiment {
  final String id; // ej. 'vinagre'
  final String title;
  final List<String> materials;
  final List<String> steps;
  final List<Question> questions;

  const Experiment({
    required this.id,
    required this.title,
    required this.materials,
    required this.steps,
    required this.questions,
  });
}

enum Subject { quimica, fisica, biologia }

extension SubjectX on Subject {
  String get label {
    switch (this) {
      case Subject.quimica:
        return 'Química';
      case Subject.fisica:
        return 'Física';
      case Subject.biologia:
        return 'Biología';
    }
  }

  /// Coincide con el id usado en los logros originales
  /// (logro_quimica_1, logro_fisica_1, logro_biologia_1).
  String get achievementPrefix {
    switch (this) {
      case Subject.quimica:
        return 'quimica';
      case Subject.fisica:
        return 'fisica';
      case Subject.biologia:
        return 'biologia';
    }
  }
}
