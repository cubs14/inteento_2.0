// Service worker de Firebase Cloud Messaging para VirtLab en Web.
// Necesario para recibir notificaciones push cuando la pestaña/PWA
// está en segundo plano o cerrada.
//
// Los valores __FIREBASE_*__ son reemplazados en el workflow de
// GitHub Actions (deploy-web.yml) con los mismos datos públicos del
// "Web app" de Firebase que usa lib/firebase_options.dart.

importScripts('https://www.gstatic.com/firebasejs/10.13.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "__FIREBASE_WEB_API_KEY__",
  authDomain: "__FIREBASE_WEB_AUTH_DOMAIN__",
  projectId: "__FIREBASE_WEB_PROJECT_ID__",
  storageBucket: "__FIREBASE_WEB_STORAGE_BUCKET__",
  messagingSenderId: "__FIREBASE_WEB_MESSAGING_SENDER_ID__",
  appId: "__FIREBASE_WEB_APP_ID__",
});

const messaging = firebase.messaging();
